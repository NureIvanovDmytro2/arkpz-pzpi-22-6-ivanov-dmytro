﻿using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class AdminController : ControllerBase
{
    private readonly VehicleService _service;

    public AdminController(VehicleService service)
    {
        _service = service;
    }

    [HttpGet("total-vehicles")]
    public IActionResult GetTotalVehicles()
    {
        int count = _service.GetTotalVehicles();
        return Ok(new { TotalVehicles = count });
    }

    [HttpGet("vehicles-by-year/{year}")]
    public IActionResult GetVehiclesByYear(int year)
    {
        var vehicles = _service.GetVehiclesByYear(year);
        return Ok(vehicles);
    }
}
