﻿using System.Globalization;
using VehicleManagementAPI.Data;
using VehicleManagementAPI.Models;

public class VehicleService
{
    private readonly VehicleDbContext _context;

    public VehicleService(VehicleDbContext context)
    {
        _context = context;
    }

    public int GetTotalVehicles()
    {
        return _context.Vehicles.Count();
    }

    public List<Vehicle> GetVehiclesByYear(int year)
    {
        return _context.Vehicles.Where(v => v.Year == year).ToList();
    }
}
